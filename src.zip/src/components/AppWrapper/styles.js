import {StyleSheet} from 'react-native';
export const styles = StyleSheet.create({
  conatiner: {
    flex: 1,
  },
  conentContainer: {
    flex: 1,
    // paddingLeft: 10,
    // paddingRight: 10,
  },
});
