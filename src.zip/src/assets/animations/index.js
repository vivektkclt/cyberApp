const animations = {
  loginIcon: require('./loginIcon.json'),
  loader: require('./loader.json'),
  emptyDocs: require('./emptyDocs.json'),
};
export default animations;
