const images = {
  user: require('./user.png'),
  titleName: require('./title_name.png'),
  splashImage: require('./RAPID_Mobile.jpg'),
  rapidLogo: require('./rapid_logo.png'),
  stationIcon: require('./station_Icon.png'),
};
export default images;
