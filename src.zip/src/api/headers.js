export const configHeader = () => {
  return {
    Accept: 'application/json',
    'Content-Type': 'application/json',
  };
};
