export const BASE_URL = 'https://rapidapi.keralapolice.gov.in/api/';

export const LOGIN = BASE_URL + 'User/Login/%7Busername%7D/%7Bpassword%7D';

export const GET_TOKEN = BASE_URL + 'Values/GetToken';

export const GET_FIR = BASE_URL + 'Values/GetFIR';

export const UPDATE_FIR = BASE_URL + 'Values/SaveLocation?';
