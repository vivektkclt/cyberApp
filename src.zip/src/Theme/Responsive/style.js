const string = {
  app: 'Developed By',
  version: 'vivektkclt@gmail.com',
};
export default string;
