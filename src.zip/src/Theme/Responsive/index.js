import {Dimensions} from 'react-native';

export const height = Dimensions.get('window').height;
export const width = Dimensions.get('window').width;
