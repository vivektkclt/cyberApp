const appColors = {
  white: 'white',
  background: '#2b1f6e',
  placeHolderWhite: '#d6d6d6',
  transPrentWhite: 'rgba(255, 255, 255, 0.3)',
};

export default appColors;
